module.exports = {
  'projectId': '4b7344',
  e2e: {},
}
